package com.grzegorz.room;

import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.recyclerview.widget.RecyclerView;

public class TagViewHolder extends RecyclerView.ViewHolder {
    private final EditText tagNameEditText;
    private final ImageButton deleteTagButton;
    private final ImageButton saveTagButton;

    public TagViewHolder(View itemView) {
        super(itemView);
        tagNameEditText = itemView.findViewById(R.id.tag_name_edittext);
        deleteTagButton = itemView.findViewById(R.id.delete_tag_button);
        saveTagButton = itemView.findViewById(R.id.save_tag_button);
    }

    public EditText getTagNameEditText() {
        return tagNameEditText;
    }

    public ImageButton getDeleteTagButton() {
        return deleteTagButton;
    }

    public ImageButton getSaveTagButton() {
        return saveTagButton;
    }
}