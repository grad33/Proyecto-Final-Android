package com.grzegorz.room;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.grzegorz.room.db.AppDatabase;
import com.grzegorz.room.db.Tag;
import com.grzegorz.room.db.TagsDao;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.SingleObserver;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TagListAdapter extends RecyclerView.Adapter<TagListAdapter.TagViewHolder> {

    private List<Tag> mTagList;
    private LayoutInflater mInflater;
    private TagClickListener mClickListener;

    public TagListAdapter(Context context, List<Tag> tagList, TagClickListener clickListener) {
        mInflater = LayoutInflater.from(context);
        mTagList = tagList;
        mClickListener = clickListener;
    }

    public TagListAdapter(List<Tag> tagList) {
        mTagList = tagList;
    }

    @NonNull
    @Override
    public TagViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.row_tag_layout, parent, false);
        return new TagViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TagViewHolder holder, int position) {
        Tag currentTag = mTagList.get(position);
        holder.tagNameTextView.setText(currentTag.tag);
    }

    @Override
    public int getItemCount() {
        return mTagList.size();
    }

    public interface TagClickListener {
        void onTagClick(Tag tag);
    }

    class TagViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView tagNameTextView;

        public TagViewHolder(@NonNull View itemView) {
            super(itemView);
            tagNameTextView = itemView.findViewById(R.id.tag_name_edittext);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) {
                int position = getAdapterPosition();
                Tag tag = mTagList.get(position);
                mClickListener.onTagClick(tag);
            }
        }
    }
}
