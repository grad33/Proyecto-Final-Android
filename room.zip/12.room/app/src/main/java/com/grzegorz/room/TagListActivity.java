package com.grzegorz.room;

import static com.grzegorz.room.EditNotaActivity.TAG;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.grzegorz.room.db.AppDatabase;
import com.grzegorz.room.db.Tag;
import com.grzegorz.room.db.TagsDao;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.annotations.NonNull;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class TagListActivity extends AppCompatActivity {

    private TagListAdapter mTagAdapter;
    private List<Tag> mTagList;

    @SuppressLint("CheckResult")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tag_list);

        mTagList = new ArrayList<>();
        mTagAdapter = new TagListAdapter(mTagList);

        RecyclerView recyclerView = findViewById(R.id.tag_list);
        recyclerView.setAdapter(mTagAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        AppDatabase appDatabase = ((RoomApplication) getApplication()).appDatabase;
        appDatabase.TagsDao().getAll()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Tag>>() {
                    @Override
                    public void accept(List<Tag> tags) {
                        mTagList.clear();
                        mTagList.addAll(tags);
                        mTagAdapter.notifyDataSetChanged();
                    }
                });

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Tags");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.tag_list_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }if(item.getItemId() == R.id.menu_add_tag){
            Tag tag=new Tag();
        }
        return super.onOptionsItemSelected(item);
    }
}
